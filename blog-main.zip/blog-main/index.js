// var numFiles = 2;

// var jsonData = [];

// for 
// jsonData.push()
// // var data = JSON.parse(fs.readFileSync('./posts/'));